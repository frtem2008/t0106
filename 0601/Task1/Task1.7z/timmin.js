console.log("Hello there");

class Timmin {
    constructor() {
        console.log("Loh has been created");
    }

    printLohName = () => {
        console.log("TIMUUUUUR MUR MUR");
    };
}

let loh = new Timmin();

loh.printLohName();
